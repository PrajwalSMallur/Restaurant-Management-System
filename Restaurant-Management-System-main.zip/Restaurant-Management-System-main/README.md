# Restaurant-Management-System
● Using HTML, CSS, JavaScript, Python, Django, SQLite  ● Developed an order management system, achieving real-time processing of customer orders.  ● Implemented a menu and inventory tracking feature, processing hundreds of daily transactions and ensuring smooth  kitchen operations.
